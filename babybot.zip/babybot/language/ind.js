exports.wait = () => {
	return`*_Sedang diproses, mohon tunggu sebentar!..._*`
}

exports.succes = () => {
	return`*「 SUKSES 」*`
}

exports.lvlon = () => {
	return`*「❗」ENABLE LEVELING*`
}

exports.lvloff = () => {
	return`*「❗」DISABLE LEVELING*`
}

exports.lvlnul = () => {
	return`*「❗」LEVELMU MASIH KOSONG*`
}

exports.lvlnoon = () => {
	return`*「❗」LEVEL DI GRUB BELUM DI AKTIFKAN*`
}

exports.noregis = () => {
	return`*「 BELUM DAFTAR 」*
*cara daftar #daftar nama|umur*
*contoh #daftar ara|17*`
}

exports.baned = () => {
	return`*「❗」SORRY SORRY AJA NIH BRO, TAPI KAU SUDAH KU BANNED YAHAHAHA HAYUUU :V*`
}

exports.premium = () => {
	return`*「❗」Maaf Kamu Bukan User Premium ! hubungi owner untuk jadi premium ketik ${prefix}owner*`
}

exports.rediregis = () => {
	return`*「 SUDAH DAFTAR 」*`
}

exports.stikga = () => {
	return`*「 GAGAL 」Coba ulangi lain kali kak*`
}

exports.linkga = () => {
	return`*「❗」maaf linknya tidak valid kak*`
}

exports.groupo = () => {
	return`[❗] Perintah ini hanya bisa di gunakan dalam group!`
}

exports.ownerb = () => {
	return`[❗] Ku tengok Mukak Kau Kek Donald Trump! Kau Siapa? Kau Bukan Owner Aku Njierrr! Kau Jelek Wajah Kau Gak terdeteksi soalnya👎`
}

exports.ownerg = () => {
	return`[❗] Ku tengok Mukak Kau Kek Donald Trump! Kau Siapa? Kau Bukan Owner Aku Njierrr! Kau Jelek Wajah Kau Gak terdeteksi soalnya👎`
}

exports.admin = () => {
	return`[❗] Perintah ini hanya bisa di gunakan oleh admin group!`
}

exports.badmin = () => {
	return`[❗] Perintah ini hanya bisa di gunakan ketika bot menjadi admin!`
}

exports.nsfwoff = () => {
	return`*「❗」NSFW GAK AKTIF*`
}

exports.bug = () => {
	return`*Masalah telah di laporkan ke owner BOT, laporan palsu/main2 tidak akan ditanggapi*`
}

exports.wrongf = () => {
	return`*「🤔」Teks nya mana kak?*`
}

exports.clears = () => {
	return`*「🚮」Clear all Success*`
}

exports.pc = () => {
	return`*「❗」REGISTRASI*\n\nuntuk mengetahui apa kamu sudah terdaftar silahkah check message yang saya kirim \n\nNOTE:\n*jika kamu belum mendapatkan pesan. berarti kamu belum menyimpan nomer bot*`
}

exports.registered = (namaUser, umurUser, serialUser, time, sender, botName) => {
	return`\`\`\`Pendaftaran berhasil dengan SN : ${serialUser}\`\`\`\n\n *╭═* ⃟ ⃟  ━ೋ๑—๑ೋ━ ⃟ ⃟ *═╮ \n\n*${time}* \n\n*Nama :* ${namaUser} \n*Umur :* ${umurUser} \n*Nomor :* wa.me/${sender.split("@")[0]}\n\n*╰═* ⃟ ⃟  ━ೋ๑—๑ೋ━ ⃟ ⃟ *═╯ \n\n*Untuk menggunakan bot* \n*silahkan ketik ${prefix}help*`
}

exports.cmdnf = (prefix, command) => {
	return`command *${prefix}${command}* tidak di temukan\coba tulis *${prefix}menu*`
}

exports.owneresce = (pushname) => {
	return`*maaf tapi ${pushname} bukan owner script*`
}
exports.levelup = (pushname, sender, getLevelingXp,  getLevel, getLevelingLevel) => {
	return`
*「 SELAMAT 」*
➸ *Nama* : ${pushname}
➸ *Nomor* : wa.me/${sender.split("@")[0]}
➸ *Xp* : ${getLevelingXp(sender)}
➸ *Level* : ${getLevel} ➸ ${getLevelingLevel(sender)}
`}
 
exports.limitend = (pushname) => {
	return`*maaf ${pushname} limit hari ini habis*\n*limit di reset setiap jam 24:00*`
}

exports.limitcount = (limitCounts) => {
	return`
*「 LIMIT COUNT 」*
sisa limit anda : ${limitCounts}

Upgrade premium bosku, biar bebas gunain bot`
}

exports.satukos = () => {
	return`*Tambah parameter 1/enable atau 0/disable`
}

exports.uangkau = (pushname, sender, uangkau) => {
	return`┏━━━━━━━♡ *ATM* ♡━━━━━━━┓\n┃╭───────────────────\n┃│➸ NAMA : ${pushname}\n┃│➸ NOMOR : ${sender.split("@")[0]}\n┃│➸ UANG : ${uangkau}\n┃╰───────────────────\n┗━━━━━━━━━━━━━━━━━━━━┛`
}

const cara = (pushname, prefix, botName, ownerName) => { 
	return `🔰 -----[ *PANDUAN PENGGUNAAN ${botName}* ]----- 🔰
Hallo, ${pushname} 👋
Berikut adalah cara penggunaan *${botName}*
         ────────────────
Kalo gak paham tuh baca dulu -_-
         ────────────────
➸ *${prefix}sticker*
Kirim gambar/video dengan caption sticker
➸ *${prefix}ttp*
Text to sticker contoh : ${prefix}ttp Lann ID
➸ *${prefix}tts*
Suara google contoh : ${prefix}tts id Hallo Ramlan
➸ *${prefix}toimg*
Reply sticker yang mau dijadiin image
➸ *${prefix}nulis*
Untuk menulis dibuku
➸ *${prefix}stalkig*
Stalking instagram contoh : ${prefix}stalkig iamramlan_
➸ *${prefix}quotes*
Random quotes
➸ *${prefix}bikinquote*
Membuat quotes contoh : ${prefix}bikinquote Kamu gay & Ramlan
➸ *${prefix}play*
Mendownload lagu dari youtube bisa menggunakan text atau link
➸ *${prefix}yutubdl*
Mendownload video dari youtube, gunakan link ya kak
➸ *${prefix}tiktod*
Mendownload video tiktok, gunakan link kak
➸ *${prefix}hartatahta*
Membuat lomgo, contoh : ${prefix}hartatahta Nadia
➸ *${prefix}pornhub*
Membuat logo, contoh : ${prefix}pornhub Ramlan & Hub
Note : untuk logo maker / image maker jika undefined berarti harus memakai &
➸ *${prefix}fitnah*
Only grup untuk fitnah orang, contoh : ${prefix}fitnah @tagtarget & Hai & Hai juga
➸ *${prefix}mutual*
Gacha nomor yang ada di database / yang menggunakan bot
         ────────────────
Note : Sisanya gunain otak kalian aja cape w jelasin :)
         ────────────────
🔰 -----[ *TUMTOR BY RAMLAN ID* ]----- 🔰
`
}

exports.cara = cara